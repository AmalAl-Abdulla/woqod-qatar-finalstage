package cmps312.qu.edu.qa.woqodfuelqatar;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class CalculateCostOld extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
Spinner spinner;
    String[] types={"DIESEL","GASOLINE PREMIUM (91)","GASOLINE SUPER (95)"};
    EditText liters;
    TextView totalcost;
    private String woqodUrl = "http://www.woqod.com/EN/Gas/Pages/Fuel-Price.aspx";
    private String fuelType = "WOQODPetrolType";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculate_cost);
        liters = (EditText) findViewById(R.id.enteredLiters);
        totalcost =(TextView) findViewById(R.id.totalcost);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(CalculateCostOld.this,android.R.layout.simple_spinner_item,types);
        //spinner =(Spinner) findViewById(R.id.spinner1);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);


    }

    private class ReadDataThread extends AsyncTask<String,Double,String> {
       String theType,Theliters;


        public ReadDataThread(String type,String l){
           this.theType =type;
           this.Theliters=l;
       }
        HttpURLConnection connection;
        // ArrayList<ExtractData> data = new ArrayList<>();
        InputStream inputStream;
        Double data;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(CalculateCostOld.this,"Uploading data. . .",Toast.LENGTH_LONG).show();
        }

        @Override
        protected String doInBackground(String... urls) {

            try {

                return extractInfoFromWoqod(urls[0]);
            } catch (Exception e) {
                e.printStackTrace();
                return "erorr!";

            }
        }

        @Override
        protected void onProgressUpdate(Double... values) {
            super.onProgressUpdate(values[0]);
        }

        @Override
        protected void onPostExecute(String result) {
            Double price,cost;
            String p = null;
            if (result.contains(theType)) {
                 p = result.substring(result.indexOf(":") + 1, result.lastIndexOf("\""));

                Toast.makeText(getBaseContext(), p, Toast.LENGTH_LONG).show();
            }

            cost= Double.valueOf(Theliters)*Double.valueOf(p);
                totalcost.setText(cost.toString());
        }


        private String extractInfoFromWoqod(String address) throws Exception {

            URL url = null;
            try {
                url = new URL(address);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            };
            StringBuilder stringBuilder = new StringBuilder();
            HttpURLConnection urlConnection = null;
            try {
                urlConnection = (HttpURLConnection) url.openConnection();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                InputStream content = new BufferedInputStream(
                        urlConnection.getInputStream());
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(content));
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                urlConnection.disconnect();
            }
            return stringBuilder.toString();
        }


    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        String userLiters = liters.getText().toString();

        switch(i){

            case 0:
               // CalculateCostOld.ReadDataThread dataThread= new CalculateCostOld.ReadDataThread("DIESEL",userLiters);
               // dataThread.execute(woqodUrl,userLiters);

                break;
            case 1:
                //CalculateCostOld.ReadDataThread dThread= new CalculateCostOld.ReadDataThread("GASOLINE PREMIUM (91)",userLiters);
                //dThread.execute(woqodUrl,userLiters);

                break;
            case 2:
                //CalculateCostOld.ReadDataThread dTh =new CalculateCostOld.ReadDataThread("GASOLINE SUPER (95)",userLiters);
                //dTh.execute(woqodUrl);


        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
        //if nothing was selected what?
    }
}
