package cmps312.qu.edu.qa.woqodfuelqatar;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by mooli_000 on 12/26/2017.
 */

public class PetrolAdapter extends ArrayAdapter<ExtractData> {

    public PetrolAdapter(Context c, ArrayList<ExtractData> extractDataArrayList){
        super(c,0,extractDataArrayList);
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ExtractData data = getItem(position);
        if(convertView == null){
            LayoutInflater.from(getContext()).inflate(R.layout.petrol_row,null);
        }

        TextView petrolName = convertView.findViewById(R.id.petrolName);
        TextView petrolValue = convertView.findViewById(R.id.petrolValue);


        petrolName.setText(data.getFuelType());
        petrolValue.setText(data.getFuelPrice()+"");

        return super.getView(position, convertView, parent);
    }
}
