package cmps312.qu.edu.qa.woqodfuelqatar;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class SummaryDataBase extends SQLiteOpenHelper{

    final static String DATABASE_NAME = "summaryDataBase";
    final static int DATABASE_VERSION = 1;
    final static String TABLE_SUMMARIES = "summaryTable";
    final static String COLUMN_FUEL_PRICE = "fuelPrice";
    final static String COLUMN_DATE = "date";
    final static int COLUMN_NUMBER = 0;
    final static String COLUMN_LITER_AMOUNT = "litersAmount";
    final static String COLUMN_FUEL_TYPE = "type";
    final static String COLUMN_COST = "cost";

    public SummaryDataBase(Context context){
        super(context, DATABASE_NAME,null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        String sqlCreate = "create table "
                + TABLE_SUMMARIES +" ("
                + COLUMN_NUMBER+" INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_DATE+" TEXT,"
                + COLUMN_FUEL_TYPE+" TEXT,"
                + COLUMN_FUEL_PRICE+" TEXT,"
                + COLUMN_LITER_AMOUNT+" TEXT"
                + COLUMN_COST+ "TEXT" +")";
        sqLiteDatabase.execSQL(sqlCreate);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists "+TABLE_SUMMARIES);
        onCreate(sqLiteDatabase);
    }

    public void addItem(String date, String type, String price, String amount,String cost) {
        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE,date);
        values.put(COLUMN_FUEL_TYPE,type);
        values.put(COLUMN_DATE,date);
        values.put(COLUMN_FUEL_PRICE,price);
        values.put(COLUMN_LITER_AMOUNT,amount);
        values.put(COLUMN_COST,cost);
        database.insert(TABLE_SUMMARIES,null,values);
        database.close();
    }


    public Cursor getAllItems(){
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("select * from "+TABLE_SUMMARIES,null);
        return cursor;
    }


    public int deleteItems(int position){
        SQLiteDatabase database = this.getReadableDatabase();
        return database.delete(TABLE_SUMMARIES," position = ?", new String[] {String.valueOf(position)});
    }
}
