package cmps312.qu.edu.qa.woqodfuelqatar;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    private ListView petrolList;
    private TextView view;
    private Button calculateCost, summaries;
    private String woqodUrl = "http://www.woqod.com/EN/Gas/Pages/Fuel-Price.aspx";
    private String fuelType = "WOQODPetrolType";
    private String fuelPrice = "xPortalPriceOWSNMBR";
    private boolean isSearchOver = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        calculateCost = (Button) findViewById(R.id.calculate_cost);
        summaries = (Button) findViewById(R.id.summaries);
        //view = (TextView)  findViewById(R.id.test);
        //petrolList = (ListView) findViewById(R.id.list_petrol);
        ReadDataThread dataThread= new ReadDataThread();
        dataThread.execute(woqodUrl);


        summaries.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToSummaries = new Intent(MainActivity.this,SummariesActivity.class);
                startActivity(goToSummaries);
            }
        });

        calculateCost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent goToCalcuateCost = new Intent(MainActivity.this,CalculateCostOld.class);
                startActivity(goToCalcuateCost);
            }
        });
    }


    private class ReadDataThread extends AsyncTask<String,Void,String> {
        HttpURLConnection connection;
        ArrayList<ExtractData> data = new ArrayList<>();
        InputStream inputStream;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            Toast.makeText(MainActivity.this,"Uploading data. . .",Toast.LENGTH_LONG).show();
        }

        @Override
        protected String doInBackground(String... urls) {
            StringBuilder sp = new StringBuilder();
            String line;
            BufferedReader br = null;
           try {
               connection = (HttpURLConnection) new URL(urls[0]).openConnection();
               connection.setConnectTimeout(5000);
               connection.setReadTimeout(3000);

               inputStream = new BufferedInputStream(connection.getInputStream());
               BufferedInputStream bis = new BufferedInputStream(inputStream);
               br  = new BufferedReader(new InputStreamReader(bis));

           }catch (Exception e){
               Log.d(MainActivity.class.getSimpleName(),"Error Here");
           } finally {
               if(connection!=null)
                   connection.disconnect();
           }
               try {
                   while ((line = br.readLine()) != null) {
                       sp.append(line);
                   }
               } catch (IOException e) {
                   Log.e(MainActivity.class.getSimpleName(),"Error Getting type and price");
               }





            return sp.toString();
        }

        /**
        @Override
        protected ArrayList<ExtractData> doInBackground(String... urls) {
            try {
                connection = (HttpURLConnection) new URL(urls[0]).openConnection();
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(3000);

                inputStream = new BufferedInputStream(connection.getInputStream());



                Log.e(MainActivity.class.getSimpleName(),"Connection Error!!!");

                ExtractData extractData = new ExtractData();
                String type = null ,price = null;
                BufferedInputStream bis = new BufferedInputStream(inputStream);
                BufferedReader br = new BufferedReader(new InputStreamReader(bis));
                StringBuilder sp = new StringBuilder();
                String line;

                try {
                    while ((line = br.readLine()) != null) {
                        sp.append(line);
                        if(line.contains(fuelType))
                            type = line.trim().substring(line.indexOf(":") + 1, line.lastIndexOf("\""));
                        else if(line.contains(fuelPrice))
                            price = line.trim().substring(line.indexOf(":") + 1, line.lastIndexOf("\""));

                        extractData.setFuelType(type);
                        extractData.setFuelPrice(Double.parseDouble(price));
                        data.add(extractData);
                    }
                } catch (IOException e) {
                    Log.e(MainActivity.class.getSimpleName(),"Error Getting type and price");
                }
                Log.e(MainActivity.class.getSimpleName(),"Error Extracting Data!!!");

            }catch (Exception e){
                Log.e(MainActivity.class.getSimpleName(),"Error Here!!!");
            }finally {
                if(connection!=null)
                    connection.disconnect();
            }

            return data;
        }
*/

        @Override
        protected void onProgressUpdate(Void... values) {
            super.onProgressUpdate(values);
        }
/**
        @Override
        protected void onPostExecute(ArrayList<ExtractData> extractData) {
            super.onPostExecute(extractData);
            PetrolAdapter adapter = new PetrolAdapter(MainActivity.this,extractData);
            petrolList.setAdapter(adapter);
        }


        */

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);

            view.setText(s);
        }
    }


    private ArrayList<ExtractData> extractInfoFromWoqod(InputStream inputStream) throws Exception{

        ArrayList<ExtractData> dataArrayList = new ArrayList<>(3);
        String type = null ,price = null;
        ExtractData extractData = new ExtractData();

        BufferedInputStream bis = new BufferedInputStream(inputStream);
        BufferedReader br = new BufferedReader(new InputStreamReader(bis));
        StringBuilder sp = new StringBuilder();
        String line;

        try {
            while ((line = br.readLine()) != null) {
                sp.append(line);
                if(line.contains(fuelType))
                    type = line.trim().substring(line.indexOf(":") + 1, line.lastIndexOf("\""));
                else if(line.contains(fuelPrice))
                    price = line.trim().substring(line.indexOf(":") + 1, line.lastIndexOf("\""));



            }


        } catch (IOException e) {
            Log.e(MainActivity.class.getSimpleName(),"Error Getting type and price");
        }


        extractData.setFuelType(type);
        extractData.setFuelPrice(Double.parseDouble(price));
        dataArrayList.add(extractData);


        return  dataArrayList;
    }


}
