package cmps312.qu.edu.qa.woqodfuelqatar;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class SummariesActivity extends AppCompatActivity {

    private ListView summariesList;
    private ArrayList<UserSummary> userSummariesList;
    private String fuelType, fuelPrice, fuelAmount, date, cost;
    private TextView textViewDate,textViewFuelAmount,textViewPrice,textViewCost,textViewFuelType;
    private SummaryDataBase dataBase;
    private SummaryAdapter adapter = new SummaryAdapter(SummariesActivity.this,userSummariesList);
    private Cursor cursor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summaries);
        summariesList = (ListView) findViewById(R.id.list_summaries);
        userSummariesList = new ArrayList<>();
        summariesList.setAdapter(adapter);
        dataBase = new SummaryDataBase(this);

        SharedPreferences p=getSharedPreferences("MyData",MODE_PRIVATE);
        fuelType = p.getString("type","");
        fuelPrice = p.getString("price","");
        fuelAmount =p.getString("amount","");
        date = p.getString("date","");
        cost = p.getString("cost","");


        dataBase.addItem(date,fuelType,fuelPrice,fuelAmount,cost);

    }

    private class SummaryAdapter extends ArrayAdapter<UserSummary>{

        public SummaryAdapter(Context c, ArrayList<UserSummary> summariesList){
            super(c,0,summariesList);
        }

        @NonNull
        @Override
        public View getView(final int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            UserSummary userSummary = getItem(position);

            if(convertView==null){
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.summaties_list_row,null);
            }


            textViewDate = (TextView) convertView.findViewById(R.id.date);
            textViewFuelAmount = (TextView) convertView.findViewById(R.id.fuel_amount);
            textViewPrice = (TextView) convertView.findViewById(R.id.fuel_price);
            textViewFuelType = (TextView) convertView.findViewById(R.id.fuel_type);
            textViewCost = (TextView) convertView.findViewById(R.id.cost);


            cursor = dataBase.getAllItems();


             while(cursor.moveToNext()) {

                userSummariesList.add(new UserSummary(cursor.getString(1),cursor.getString(2),
                        cursor.getString(3),cursor.getString(4)
                ,cursor.getString(5)));


            }


            textViewDate.setText(userSummary.getDate());
            textViewFuelType.setText(userSummary.getType());
            textViewPrice.setText(userSummary.getPrice());
            textViewFuelAmount.setText(userSummary.getFuelAmount());
            textViewCost.setText(userSummary.getCost());


            convertView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {

                    summariesList.removeView(view);
                    dataBase.deleteItems(view.getId());
                    return true;
                }
            });

            return super.getView(position, convertView, parent);
        }
    }

}
